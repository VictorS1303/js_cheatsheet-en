/* KONSOLLEN */


/* LOGGING */

/*
    Konsollens primære formål er til at fejlsøge ens kode.
    Dette kan være alt fra almindelig tekst til kode.
*/


/*
    // console.log() //
    console.log() er den metode, man bruger til at få noget udskrevet i konsollen.
    Det, man gerne vil have udskrevet, skrives inde i parenteserne. Vil man gerne have udskrevet almindelig tekst,
    er det vigtigt, at man husker citationstegn omkring teksten (enten enkelte ('') eller dobbelte ("")), da det ellers vil blive betraget som kode af konsollen. Vil man derimod gerne have udskrevet kode, skal der ikke citationstegn omkring dette. Det er muligt at udskrive tekst og kode på en gang.

    Det er typisk variable, man logger. Her er det værdien af variablen, der bliver skrevet ud i konsollen, og ikke selve variablens navn.

    Se eksempler på det hele nedenunder.
*/


/* ALMINDELIG TEKST */

/*
    For at logge almindelig er det meget enkelt, hvad man gør, hvilket er vist i eksemplet herunder.

    Eksempel:
        console.log('Dette er almindelig tekst!') (enkelte citationstegn)
        eller
        console.log("Dette er almindelig tekst!") (dobbelt citationstegn)

    Prøv at fjerne kommenteringen af eksemplet nedenunder og se, at begge dele udskriver præcis det samme i konsollen.
*/

/*
    console.log('Dette er almindelig tekst!')
    console.log("Dette er almindelig tekst!")
*/


/* KODE */
/*
    Når man vil logge kode for at se, hvad for eksempel værdien af ens variabel er, er proceduren den samme som ved almindelig tekst - bortset fra, at man her ikke anvender citationstegn.

    Eksempel:
    Vi har en variabel kaldet "firstName":
        
        let firstName = "Julie"
    
    Vi ønsker at se i konsollen, hvad værdien af "firstName"-variablen er.
    
    Dette gør vi således:
    console.log(firstName)

    Prøv at fjerne kommenteringen af eksemplet nedenunder og se, at der bliver udskrevet "Julie" i konsollen.
*/

/*
    let firstName = "Julie"
    console.log(firstName)
*/



/* ALMINDELIG TEKST + KODE */
/*
    Det er også muligt at logge almindelig tekst og kode samtidigt.
    Dette gøres ved, at man mellem sin tekst og variabel har et '+'.
    Dette er det, der hedder concatenation (på dansk "sammenføjning"), som gør, at et stykke kode eller en tekststreng kan blive sat ind i en anden tekststreng.

    Eksempel:
    Vi vil gerne logge: "Hej, jeg hedder " efterfulgt af et navn.
    
    Vi opretter derfor først en variabel, som vi giver en værdi:
        let firstName = "Victor"
    
    console.log('Hej, jeg hedder ' + firstName)

    I eksemplet ovenfor har vi først teksten "Hej, jeg hedder ".
    Dette efterfølges af plusset, som binder den efterfølgende variabel "firstName", sammen med "Hej, jeg hedder ",
    så der kommer til at så "Hej, jeg hedder Victor".

    Prøv at fjerne kommenteringen af eksemplet nedenunder og se, at der bliver udskrevet "Hej, jeg hedder Victor" i konsollen.
*/

/*
    let firstName = "Victor"
    console.log('Hej, jeg hedder ' + firstName)
*/




/* FEJLBESKEDER */
/*
    Konsollen er også det sted, hvor du får fejlbeskeder. Der er en fejlbesked til stort set enhver tænkelig situation.
    Man skal på ingen måde kunne dem allesammen, og det er heller ikke meningen, at man skal lære dem (alle) udenad (dette er mildest talt umuligt).

    Man tager dem derfor, som man støder på dem. I eksemplet her bliver de tre fejlbeskeder, du oftest vil støde på på første semester, når det kommer til at hente elementer fra din HTML ind i din JavaScript, forklaret.
*/

/*
    // null //
    "null" er computersprog og betyder "ingenting". Denne fejlbesked forekommer i forbindelse med at hente et element ind, når man forsøger at hente et element ind via en attribut, som elementet ikke har. Denne besked forekommer, uanset om du bruger .getElementById(), .querySelector() eller en helt tredje metode til at få et element hentet ind i din JavaScript.

    Kort fortalt får du "null", fordi du forsøger at hente et element, der ikke eksisterer, ind i din JavaScript.

    Eksempel:
    Vi har et <h1></h1>-element i HTML'en med et id kaldet "header" (se index.html).
    
    Dette element henter vi ind via dets id:

        const header = document.getElementById('head')
    
    
    Herefter logger vi variablen "header"

        console.log(header)
    
    Her forventes det, at '<h1 id="header"></h1>' logges til konsollen, men I stedet får vi "null".
    Dette sker, fordi vi forsøger at tage fat på elementet via dets id med et forkert navn (elementets id har værdien "header", men vi forsøger at tage fat på det med værdien "head").
    
    Prøv at fjerne kommenteringen af eksemplet nedenunder og se, at der bliver udskrevet "null" i konsollen.
*/

/*
    const header = document.getElementById('head')
    console.log(header)
*/

// LØSNING //
/*
    Der er to måder at løse denne fejl på:

        1. HTML
            Første løsning er at gå ind i HTML'en og ændre id'et således, at det matcher det, du har skrevet i parenteserne i .getElementById(). Dette gør man dog som regel ikke.
        
            
        2. JavaScript
            Den anden måde er at ændre det, der står i .getElementById(), så det matcher det id, elementet har i HTML'en. Dette er den anbefalede måde.
        

    Altså er den rigtige måde denne linje JavaScript:
        
        const header = document.getElementById('header')
*/

/*
   // 
      Uncaught ReferenceError: variableName is not defined (Chrome & Firefox)
      / 
      ReferenceError: Can't find variable: x (Safari)
   //
    
   "Uncaught ReferenceError: variableName is not defined" eller "ReferenceError: Can't find variable: x" er den fejlbesked, som du vil støde på, når du forsøger at referere til en variabel, som du ikke har defineret.

   Eksempel:
   Vi logger en variabel 'x' til konsollen:
   
       console.log(x)
   
   Da vi endnu ikke har deklareret nogen variabel med navnet 'x', vil vi få ovenstående fejlbesked.

   Prøv at fjerne kommenteringen af eksemplet nedenunder og se, at der bliver udskrevet "Uncaught ReferenceError: x is not defined" eller "ReferenceError: Can't find variable: x" i konsollen.
*/

/*
    console.log(x)
*/

// LØSNING // 
/*
    Løsningen til dette problem er dog forholdsvis simpel:
    Vi deklarerer simpelthen bare en variabel med navnet 'x'.

    Eksempel:
        let x = 3

        Herefter logger vi 'x' og ser, at vi får 3 returneret:
        console.log(x)
    
    Prøv at fjerne kommenteringen af eksemplet nedenunder og se, at der bliver udskrevet 3 i konsollen.
*/

/*
    let x = 3
    console.log(x)
*/


/*
    // 
      Uncaught ReferenceError: can't access lexical declaration 'x' before initialization (Chrome & Firefox)
      / 
      ReferenceError: Cannot access uninitalized variable (Safari)
    //

    Denne besked kan godt være lidt kryptisk at forstå. Hvad det betyder er, at man forsøger at tilgå en variabel, før man har deklareret den.

    Eksempel:
    Vi logger en variabel 'y' til konsollen.

        console.log(y)
    
    Herefter opretter vi en variabel med navnet 'y':
        let y = 4
    
    I dette tilfælde forsøger vi at logge en variabel, som JavaScript endnu ikke kender til på det tidspunkt, vi logger den. Dette resulterer i den fejlbesked, der står ovenfor.

    Prøv at fjerne kommenteringen af eksemplet nedenunder og se, at der bliver udskrevet ovenstående fejlbesked i konsollen.
*/


/*
    console.log(y)
    let y = 4
*/

// LØSNING //
/*
    Løsningen på dette problem er heldigvis simpel:
    Vi bytter ganske enkelt om på linjerne i ovenstående eksempel således, at JavaScript kender til variablen, før den logges.

    Prøv at fjerne kommenteringen af eksemplet nedenunder og se, at der bliver udskrevet 4 fejlbesked i konsollen.
*/

/*
    let y = 4
    console.log(y)
*/


/* UDFORDRING */

/*
    Disse udfordringer tester dig i blandt andet at forstå de fejlbeskeder, som er beskrevet ovenfor.
    Hver udfordring kommer med den linje JavaScript, hvor fejlen er (hvis fejlen er i JavaScripten) samt den console.log(), der fremtvinger den fejl, der skal løses. Når en udfordring er løst korrekt, vil den respektive tekst blive lysegrøn, når der trykkes på knappen lige nedenunder teksten til den pågældende opgave. Er opgaven ikke løst korrekt, vil teksten ryste og blive rød. Du kan til enhver tid trykke på knappen for at se, om du har løst opgaven korrekt.
*/



/*
    1. null
    Fjern kommentaren fra koden nedenfor og se, at der i konsollen returneres "null".
    I denne udfordring skal fejlen findes i HTML'en i index.html (i den del under kommentaren, hvor der står: "<!-- ALT HTML RELATERET TIL UDFORDRING 1 -->").
    
*/

/*
    Dette skal du ikke røre, medmindre du får brug for at nulstille opgaven.
    Er dette tilfældet, kopierer og indsætter du det bare, så det står udenfor
    kommentaren her:

    const challengeHeaderOne = document.getElementById('challenge_header_one')
    console.log(challengeHeaderOne)
*/


/*
    const challengeHeaderOne = document.getElementById('challenge_header_one')
    console.log(challengeHeaderOne)
*/





/*
    // 2. Lidt af hvert //
    I denne opgave er der flere ting, der er forkert, og det er derfor din opgave at få koden ordnet, så det stemmer overens med nedenstående oplysninger. Du skal derfor ikke selv skrive noget kode, men kun rette i det eksisterende, så det kommer til at virke.

    OBS:
    Der kan være ting i både HTML'en (i den del under kommentaren, hvor der står: "<!-- ALT HTML RELATERET TIL UDFORDRING 2 -->") og JavaScripten for denne udfordring, så du skal være vågen. 

    Oplysninger:
        -> Elementet skal vælges via id'et "challenge_header_two"

        -> Der er i alt tre ting, der skal rettes. Hvad de er,
           og hvor de hver især har gemt sig, er din opgave at finde ud af.
*/

/*
    console.log(challengeHeaderTwo)
    const challengeHeaderTwo = document.getElementById('#challengE_header_two')
*/

/*
    Dette skal du ikke røre, medmindre du får brug for at nulstille opgaven.
    Er dette tilfældet, kopiere og indsætter du det bare, så det står udenfor
    kommentaren her:

    console.log(challengeHeaderTwo)
    const challengeHeaderTwo = document.querySelector('.challenge-header-two')
*/

    
    
    

/*
    // 3. Kreer selv //
    Her skal du selv oprette et element og få det ind i JavaScripten og logget det til konsollen. Opgaven er først løst, når du ikke får en fejlbesked i konsollen men derimod elementet, og teksten bliver grøn, når du trykker på knappen.

    Inde i <header></header>-elementet i HTML'en under kommentaren "<!-- ALT HTML RELATERET TIL UDFORDRING 3 -->" skal du oprette en <h1></h1> med klassen "heading challenge-header-three" (præcis, som det står i citationstegnene her) og id'et "challenge_header_three". Teksten i elementet skal være "Udfordring 3".
    
    Derefter skal du have det ind i JavaScripten via enten dets klasse eller ID, hvorefter du skal logge det til konsollen. Variablen skal hedde "challengeHeaderThree" (stavet præcis sådan).
    
    Teksten bliver lysegrøn, når du har løst opgaven korrekt.

    OBS:
    Det er snyd bare at kopiere og indsætte klasse- og id-navnet herfra og ind i HTML'en.
*/
