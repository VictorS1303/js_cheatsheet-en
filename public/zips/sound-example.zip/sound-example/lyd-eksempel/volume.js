const audioTwo = document.getElementById('audio')
const volumeInput = document.getElementById('volume_input')
const volumeNumber = document.getElementById('volume_number')

window.addEventListener('load', () =>
{
    adjustVolume()
})

volumeInput.addEventListener('input', adjustVolume)


function adjustVolume()
{
    audioTwo.volume = volumeInput.value

    updateVolumeNumber()
}

function updateVolumeNumber()
{
    volumeNumber.textContent = Math.floor(volumeInput.value * 100) + '%'
}