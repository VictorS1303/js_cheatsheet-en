/* LYD */

/*
    For at kunne arbejde med lyd i JavaScript, skal man have et audio-element i sin HTML.
    Der er derfor allerede et audio-element i HTML'en, som også er hentet ind her. Dette er det element,
    der bliver refereret til i dette eksempel.

    I dette eksempel kommer vi også ind på, hvad attributter er. Du har allerede arbejdet med nogle før (class, id, href med videre)

    Der står i en kommentar henover audio-elementet i HTML'en, hvordan dette fungerer.
*/


// Audio-elementet
const audio = document.getElementById('audio')

/*
    // .play() //
    For at kunne afspille lyd i JavaScript, skal vi kalde .play()-metoden, som gør præcis det, den siger, den gør: afspiller lyden. Vi har en playknap til dette, som skal kalde den funktion, der får lyden til at afspille, når der trykkes på den.

    // Vi henter knappen ind og tilføjer en eventlistener
    const playButton = document.getElementById('play_btn')
    playButton.addEventListener('click', playAudio)

    function playAudio()
    {
        // Her tager vi fat i vores variabel "audio", som er referencen til audio-elementet, og kalder .play()-metoden på den ved ganske enkelt at skrive ".play()" lige efter "audio".

        audio.play()
    }

    Prøv at fjerne kommentaren fra eksemplet nedenunder og hør, at lyden bliver afspillet.

    Lad være med at udkommentere koden nedenunder igen, for du skal bruge det igen. 
*/

/*    
    const playButton = document.getElementById('play_btn')
    playButton.addEventListener('click', playAudio)

    function playAudio()
    {
        audio.play()

        // Ignorer dette
        // currentTime()
    }
*/

/*
    // .pause() //
    For at kunne pause lyd i JavaScript, skal vi kalde .pause()-metoden, som gør præcis det, den siger, den gør: pauser lyden. Vi har en pauseknap til dette, som skal kalde den funktion, der får lyden til at pause, når der trykkes på den.

    // Vi henter knappen ind og tilføjer en eventlistener
    const pauseButton = document.getElementById('pause_btn')
    pauseButton.addEventListener('click', pauseAudio)


    function pauseAudio()
    {
        // Her tager vi fat i vores variabel "audio", som er referencen til audio-elementet, og kalder .pause()-metoden på den ved ganske enkelt at skrive ".pause()" lige efter "audio".

        audio.pause()

    }

    Prøv at fjerne kommentaren fra eksemplet nedenunder og hør, at lyden bliver pauset.

    Som du bemærker, når du afspiller lyden igen efter at have pauset den, starter den fra, hvor du pausede den.
    Lyden bliver altså ikke sat tilbage start.

    Lad være med at udkommentere koden nedenunder igen, for du skal bruge det igen.
*/

/*
    const pauseButton = document.getElementById('pause_btn')
    pauseButton.addEventListener('click', pauseAudio)

    function pauseAudio()
    {
        audio.pause()
    }
*/





/*
    // .volume //
    .volume er en attribut. Det vil sige, at der ikke kommer nogen parenteser efter den (da det ellers ville have været en metode).

    .volume bruges til at styre lydstyrken af lydfilen. .volume kan have en værdi fra 0 (som er ingen lyd) til 1 (som er fuld lyd).

    Normalt styrer man lyden via en slider (den, der her er lige under start- og pauseknappen).
    Hvordan dette fungerer, gås der ikke i dybden med her.

    Som I kan se, når I begynder at trække i den, ændrer lydstyrken sig, og det samme gør tallet til højre for, som går fra 0 - 1 afhængigt af styrken (hvordan dette tal er sat op, behøver I ikke bekymre jer om. Det er bare for visuelt at vise jer, at lydstyrken ændrer sig).

    Hvis man ønsker, at lydstyrken derimod altid bare skal have samme værdi, skriver man ganske enkelt:
    audio.volume = 0.5

    Dette sætter lydstyrken til 50%.

    Prøv at trække i slideren i browseren for at ændre lydstyrken
*/


/*
    // .muted //
    .muted er også en attribut. Denne muter lyden fuldstændigt, hvilket vil sige, at hvis du trykker på mute-knappen, vil du ingen lyd kunne høre, selv hvis du skruer lyden op til højere end nul.

    Eksemplet nedenfor muter lyden, hvis man kan hører den, og unmuter den, hvis den er mutet.

    Prøv at fjerne kommentaren fra eksemplet nedenunder og hør, at lyden bliver henholdsvis muted og unmuted.

*/

/*
    const muteButton = document.getElementById('mute_btn')
    muteButton.addEventListener('click', muteAudio)

    function muteAudio()
    {
        if(audio.muted)
        {
            audio.muted = false
        }
        else
        {
            audio.muted = true
        }

    }
*/

/*
    // .duration (varighed) //
    .duration er også en attribut, hvorfor der ikke er parenteser efter.
    .duration returnerer den totale længde af lyden i sekunder.
    Det vil sige, at er lydfilen præcis et minut lang, returnerer den "60", da der er 60 sekunder på et minut.

    Vores lydfil er 3 minutter og 15 sekunder lang, hvorfor 195 udskrives, når kommentaren fjernes fra eksemplet nedenunder, da 3 minutter og 15 sekunder svarer til 195 sekunder.
*/


/*
    const duration = document.getElementById('duration')

    // Har rundet ned til nærmeste hele antal sekunder (195)
    duration.textContent = Math.floor(audio.duration)
*/

/*
    // .currentTime //
    Dette er en attribut, der fortæller med sekunder i decimaltal, hvor langt henne i lydfilen, man er.
    Det er svært at forklare mere om denne, uden det bliver for teknisk.

    Prøv at fjerne kommentaren fra eksemplet nedenunder og se, hvad der bliver logget, når der trykkes på playknappen.
*/

/*
    function currentTime()
    {
        setInterval(() =>
        {
            console.log(audio.currentTime)        
        }, 1000)
    }
*/

/* UDFORDRING */
/*
    Som du måske har lagt mærke til, er der både en .play()- og en .pause()-metode, som gør netop det, de indikerer. Men hvad så med .stop()? Den er ikke glemt i gennemgangen her. Grunden til, at den ikke er med, er, at den ganske enkelt ikke findes.

    Din udfordring er nu at få lyden til at stoppe, hvilket vil sige, at når den startes igen, starter lyden fra begyndelsen (modsat .pause(), hvor den starter fra det punkt, hvor den blev pauset).

    De trin, det kræver (udover naturligvis at få stopknappen med ind i JavaScripten og tilføje en eventlistener til den) er at pause lyden og nustille lydens nuværende tidspunkt.

    HINT:
      -> .pause()
      -> .currentTime
*/
