/* SOUND */

/*
    In order to work with sound in JavaScript, you must have an audio element in your HTML.
    There is therefore already an audio element in the HTML, which is also imported here. This is the element that
    referred to in this example.

    In this example we also get into what attributes are. You have already worked with some before (class, id, href etc.)

    A comment above the audio element in the HTML explains how this works.
*/

// The audio element
const audio = document.getElementById('audio')

/*
    // .play() //
    In order to play sound in JavaScript, we need to call the .play() method, which does exactly what it says it does: plays the sound. We have a playbutton for this, which should call the function that makes the sound play when pressed.

    // We get the button and add an event listener
    const playButton = document.getElementById('play_btn')
    playButton.addEventListener('click', playAudio)

    function playAudio()
    {
        // Here we grab our variable "audio", which is the reference to the audio element, and call the .play() method on it by simply writing ".play()" right after "audio".

        audio.play()
    }

    Try uncommenting the example below and hear the audio play.

    Please do not comment out the code below again, as you will need it again. 
*/

/*    
    const playButton = document.getElementById('play_btn')
    playButton.addEventListener('click', playAudio)

    function playAudio()
    {
        audio.play()

        // Ignore this
        // currentTime()
    }
*/


/*
    // .pause() //
    To pause audio in JavaScript, we need to call the .pause() method, which does exactly what it says it does: pause the audio. We have a pause button for this, which should call the function that pauses the audio when pressed.

    // We fetch the button and add an event listener
    const pauseButton = document.getElementById('pause_btn')
    pauseButton.addEventListener('click', pauseAudio)


    function pauseAudio()
    {
        // Here we grab our variable "audio", which is the reference to the audio element, and call the .pause() method on it by simply writing ".pause()" right after "audio".

        audio.pause()

    }

    Try removing the comment from the example below and hear the audio pause.

    As you notice, when you play the audio again after pausing it, it starts from where you paused it.
    The sound is therefore not reset to start.

    Please do not comment out the code below again, as you will need it again.
*/

/*
    const pauseButton = document.getElementById('pause_btn')
    pauseButton.addEventListener('click', pauseAudio)

    function pauseAudio()
    {
        audio.pause()
    }
*/



/*
    // .volume //
    .volume is an attribute. This means no parentheses come after it (since it would otherwise have been a method).

    .volume is used to control the volume of the audio file.
    .volume can have a value from 0 (which is no sound) to 1 (which is full sound).

    Normally, you control the sound via a slider (the one just below the start and pause button).
    How this works is not discussed in depth here.

    As you can see, when you start pulling it, the volume changes, and so does the number to the right of it, which goes from 0 - 1 depending on the volume (how this number is set up, you don't need to worry. It's just to visually show you that the volume changes).

    If, on the other hand, you want the volume to always just have the same value, you simply write:
    audio.volume = 0.5

    This sets the volume to 50%.

    Try dragging the slider in the browser to change the volume
*/


/*
    // .muted //
    .muted is also an attribute. This mutes the sound completely, meaning if you press the mute button, you won't be able to hear any sound even if you turn the volume up higher than zero.

    The example below mutes the sound if it can be heard, and unmutes it if it is muted.

    Try removing the comment from the example below and hear the sound become muted and unmuted respectively.

*/

/*
    const muteButton = document.getElementById('mute_btn')
    muteButton.addEventListener('click', muteAudio)

    function muteAudio()
    {
        if(audio.muted)
        {
            audio.muted = false
        }
        else
        {
            audio.muted = true
        }

    }
*/



/*
    // .duration (duration) //
    .duration is also an attribute, which is why there are no parentheses after.
    .duration returns the total length of the sound in seconds.
    That is, if the audio file is exactly one minute long, it returns "60", since there are 60 seconds in a minute.

    Our audio file is 3 minutes and 15 seconds long, so 195 is printed when the comment is removed from the example below, as 3 minutes and 15 seconds equals 195 seconds.
*/

/*
    const duration = document.getElementById('duration')

    // Have rounded down to the nearest whole number of seconds (195)
    duration.textContent = Math.floor(audio.duration)
*/


/*
    // .currentTime //
    This is an attribute that tells in seconds in decimal numbers how far along in the audio file you are.
    It's hard to explain more about this one without getting too technical.

    Try uncommenting the example below and see what is logged when the play button is pressed.
*/


/*
    function currentTime()
    {
        setInterval(() =>
        {
            console.log(audio.currentTime)        
        }, 1000)
    }
*/


/* CHALLENGE */

/*
    As you may have noticed, there are both a .play() and a .pause() method which do exactly what they indicate. But what about .stop()? It is not forgotten in the review here. The reason it is not included is that it simply does not exist.

    Your challenge now is to make the sound stop, meaning that when it is started again, the sound starts from the beginning (as opposed to .pause(), where it starts from the point where it was paused).

    The steps it requires (besides of course getting the stop button into the JavaScript and adding an event listener to it) are to pause the sound and reset the current time of the sound.

    HINT:
      -> .pause()
      -> .currentTime
*/