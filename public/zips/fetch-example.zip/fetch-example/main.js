/* FETCH */

/*
    In this review, we first review how fetch works and what it consists of. Next, three different ways are reviewed
    to write the same functionality ("The long way", "the shorter way" and "the async/await way").
    In some cases you have to accept that some things will happen that will not be detailed.

    It is important to mention that fetch returns data in the format called JSON, which stands for JavaScript Object Notation.
    In short, this means that the data that is returned is formatted as objects, which is why you can access the data in the objects
    as in all other cases where you work with objects.

    The examples below use an API that returns a single object.
*/


/*
    // Function and structure //


    1. How does fetch work?
        Imagine you are out playing with a tennis ball with your dog.
        In this case, the dog is the fetch call and the ball is the data to be returned.
        When you throw the ball, you send a request to get some data returned (in this case, the ball is the data).
        The dog (the fetch call) is sent off to fetch the ball (the data).
        Regardless of whether the dog (the fetch call) comes back with or without the tennis ball (the data), the dog (the fetch call) has performed its task correctly,
        since the dog's (called fetch) only task is to try to retrieve what you request - not necessarily to return it.
        So if you get an error message in the console (i.e. that the dog does not return with the ball) this is still a success.
    

    2. What does fetch consist of?
        All ways to make a fetch call start with typing "fetch('')",
        where inside the quotation marks in the brackets you indicate the URL from which you want to retrieve data.
        Next come two .then() methods which, in the different ways of working with the data, do something different.
*/


/*
    // The long version //
    
    In this version, we fetch the data, and then we use the two .then() methods to call a function, respectively,
    that formats the data as JSON and to call a function that accepts the formatted data and logs it to the console.


    Example:

    1. We fetch the URL

        fetch('https://www.themealdb.com/api/json/v1/1/search.php?s=Arrabiata')


    2. We add a .then() method that calls a function that formats the data as JSON
        
        fetch('https://www.themealdb.com/api/json/v1/1/search.php?s=Arrabiata').then(headersRecieved)
    

    3. We add another .then() method which calls the function that logs the data to the console
       
        fetch('https://www.themealdb.com/api/json/v1/1/search.php?s=Arrabiata').then(headersRecieved).then(dataReceived)

    
    4. We declare the function called in the first .then() method which formats the data as JSON

        function headersRecieved(response)
        {
            return response.json()
        }


    5. We declare the function called in the second .then() method that logs the data to the console

        function dataReceived(data)
        {
            console.log(data)
        }

    All these steps added together look like the example below.
    Try uncommenting the example below and see "Object { meals: (1) [...] }" being logged to the console.
*/


/*
    fetch('https://www.themealdb.com/api/json/v1/1/search.php?s=Arrabiata').then(headersRecieved).then(dataReceived)

    function headersRecieved(response)
    {
       // Her returnereres dataen som JSON ved brug af .json()-metoden 
       return response.json()
    }

    function dataReceived(data)
    {
        console.log(data)
    }
*/


/*
    There are of course faster and better ways that require less code than the above example.
    This will be looked at in the next example.
*/


/*
    // The shorter method //
    This method is very similar to what was reviewed in the example above,
    but that's why we still go through step by step what is happening here.


    Example:
    
    1. We fetch the URL

        fetch('https://www.themealdb.com/api/json/v1/1/search.php?s=Arrabiata')
    
    2. We call the "headersReceived" function directly in the first .then() method

        fetch('https://www.themealdb.com/api/json/v1/1/search.php?s=Arrabiata').then(function headersReceived(response) {
            return response.json()
        })

    3. We add another .then() method which calls the function that logs the data to the console
       
        fetch('https://www.themealdb.com/api/json/v1/1/search.php?s=Arrabiata').then(function headersReceived(response) {
            return response.json()
        }).then(dataReceived)
 

    4. We declare the function called in the second .then() method that logs the data to the console

        function dataReceived(data)
        {
            console.log(data)
        }
    
    
    All these steps added together look like the example below.
    Try uncommenting the example below and see "Object { meals: (1) [...] }" being logged to the console.
    This is therefore a shorter way of doing exactly the same as in "The long way".
*/


/*
      fetch('https://www.themealdb.com/api/json/v1/1/search.php?s=Arrabiata').then(function headersReceived(response) {


        // Here the data is returned as JSON using the .json() method 
            return response.json()
        
      }).then(dataReceived)

    function dataReceived(data)
    {
        console.log(data)
    }
*/

/*
    // async/await //
    There is an even shorter way than the ones above, and it is also this one that is recommended to be used. This is where you have to accept,
    that it is not everything that goes into depth, as it becomes too technical. First, it explains what async/await is, and then shows,
    how the same data as in the two examples above can be retrieved with a single function using async/await
    (however, this is technically a small step up from the above two ways).


    // ASYNC //
    What does "async" mean?

        JavaScript is basically synchronous. This means it runs each line separately one by one from top to bottom.
        However, asynchronous JavaScript behaves in a slightly different way.

        An asynchronous function is defined by typing the keyword "async",
        before writing "function" and the rest as with a normal function declaration.
        When JavaScript sees the "async" keyword, it takes the code (usually a function) defined with "async"
        and "takes it out" of the JavaScript file, after which it continues to complete the code in the JavaScript file it is working on.
        Only when it is done with that will the function(s) defined with "async" be run.

        Try to see if you can guess the order in which the functions below will be run.
        Then remove the comments to see if you guessed correctly (remember to comment it out again).
*/

/*
    async function getMeals()
    {
        const data = await fetch('https://www.themealdb.com/api/json/v1/1/search.php?s=Arrabiata').then(function headersReceived(response) {
            return response.json()
        })

        console.log(data)
    }
    
    function sayHi()
    {
        console.log('Hi!')
    }

    function sayGoodbye()
    {
        console.log('Goodbye!')
    }

   
    sayHi()
    getMeals()
    sayGoodbye()
*/ 



/*
    // AWAIT //

    What does "await" mean?
        
        The "await" keyword can only be used in functions declared with "async".
        What "await" does is it tells the async function to wait to do what the function says.

        Imagine you have to pick up a friend at the station.
        You haven't been given a time, so you drive right away to make sure you're not late.
        That's what a non-async function does - it runs as soon as it's notified.

        In code, this will correspond to (console.log() here corresponds to you running):

        function driveToStation()
        {
            console.log('Drive to the station!')
        }

        driveToStation()


        Now your friend says that he/she will be at the station in half an hour.
        You know it will take you ten minutes to get to the station.
        You get into your car immediately (this is the synchronous).
        You wait twenty minutes to drive. At the same time, your friend continues to run towards the station (this is equivalent to JavaScript continuing to run the code in the file it is working on).
        After the twenty minutes start, you drive so that you can be at the station at the same time as your friend (this is the asynchronous, since you have been waiting in the car).
    
    
    What we need to await in our async function is the fetch() call.
    It is all explained step by step below.
*/


/*
   Now that we know how "async" and "await" work, it's time to look at
   how we can write the code from steps 1 and 2 in a shorter way with "async/await".


   Example:
   
   1. We declare an asynchronous function called "getMeal".
       -> The only difference between this and a regular function declaration is that we start by writing "async".
    
       async function getMeal()
       {
    
       }


   2. Inside function we create a variable which should be equal to our asynchronous fetch() call
       
       async function getMeal()
       {
            const mealResponse =
       }
   
       
   3. Here we make our awaited fetch() call
       -> It is crucial that we write "await" after the equals sign and before "fetch"
    
       async function getMeal()
       {
            const mealResponse = await fetch('https://www.themealdb.com/api/json/v1/1/search.php?s=Arrabiata')
       }
    
  4. We create a variable equal to our data formatted as JSON (this must also be "await")
      
       async function getMeal()
       {
            const mealResponse = await fetch('https://www.themealdb.com/api/json/v1/1/search.php?s=Arrabiata')
            const mealResponseAsJSON = await response.json()
            console.log(data)
       }

  5. We call the function and thus the data is logged to the console as expected
       getMeal()

    
    Try uncommenting the example below and see the data being logged to the console (remember to uncomment the example again)
*/


/*
    async function getMeal()
    {
        const mealResponse = await fetch('https://www.themealdb.com/api/json/v1/1/search.php?s=Arrabiata')
        const mealResponseAsJSON = await mealResponse.json()
        console.log(mealResponseAsJSON)
    }

    getMeal()
*/



/*
    You must not understand the following. It's just to show how short the above can be made.
    Try uncommenting the example below and see that the same as in all other examples is logged to the console (remember to uncomment the example again)
*/

/*
    async function getData()
    {
        const data = await fetch('https://www.themealdb.com/api/json/v1/1/search.php?s=Arrabiata')
            .then((res) => res.json())
            .then((data) => console.log(data))
    }

    getData()
*/

/*
    As you can see, there are many ways to do the same - also when it comes to fetch.
    There is no right or wrong way to do it either, and it is therefore up to you to choose the way to do it yourself, which you yourself best understand and are familiar with.
*/



/* CHALLENGE */
/*
    URL:
    https://www.themealdb.com/api/json/v1/1/search.php?s=Arrabiata


   1. The long way/The shorter way
       Here you must use the way you feel most comfortable with, either the short or
       the long way to fetch the data from the above URL. You are welcome to look at the two ways you choose,
       but you have to write it yourself and not just copy and paste the example (with the exception of the URL, which you are welcome to copy and paste in the fetch() call.)
       You don't learn anything from just copying and pasting.

    
       // The long way //
       You must therefore (in the order below):

       1. Make a fetch() call that takes the above URL as parameters
          (Hint: Remember the quotation marks around the URL)
    

       2. Add a .then() method that calls a function that formats the data as JSON
          (Hint: The name of the function the .then() method calls is written as a parameter to the .then() method)
    

       3. Add another .then() method that calls a function that logs the data to the console
          (Hint: The name of the function the .then() method calls is written as a parameter to the .then() method)
        

       4. Declare the function that will format the data as JSON
           -> This function takes a parameter and it is this parameter on which the .json() method is to be called

          (Hint: Remember "return" as the first thing inside the function)


       5. Declare the function called in the second .then() method that logs the data to the console
           -> This function takes a parameter and it is this parameter that must be logged to the console so that the data is printed



    2. Async/await
       Here you must get the data from the same URL by using the async/await method.
       Again, you must not just copy and paste the example, but you must write it yourself, you better understand and learn it.


       1. Declare an asynchronous function
          (Hint: "async" before "function" and that the function takes a parameter which is the)
    

       2. Create a variable inside the function that should be equal to the fetch() call


       3. Write the fetch() call right after the equals sign in the variable you created in the previous step
          (Hint: remember "await" before the fetch() call)


       4. Create another variable inside the function


       5. Set the variable from the previous step to equal the data formatted as JSON
           (Hint: The name of the variable you created in step 2, followed by .json(). Remember "await" before)
    

       6. Log the variable from step 4 to the console inside the function


       7. Call the function
*/

