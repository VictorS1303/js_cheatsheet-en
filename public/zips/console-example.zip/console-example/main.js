/* THE CONSOLE */


/* LOGGING */

/*
    The primary purpose of the console is to debug the code.
    This can be everything from regular text to code.
*/


/*
   // console.log() //
    console.log() is the method you use to get something printed to the console.
    What you want to be printed is written inside the parentheses. If you would like to have plain text printed,
    it is important to remember the quotation marks around the text (either single ('') or double ("")),
    as, otherwise, it will be considered as code by the console. If, on the other hand, you would like to have code printed, there should be no quotation marks around this. It is possible to print text and code at once.

    It is typically variables that are logged. Here, it is the value of the variable that is printed to the console, and not the name of the variable itself.

    See examples of it all below.
*/


/* PLAIN TEXT */

/*
    To log normally, what you do is very simple, which is shown in the example below.

    Example:
        console.log('This is plain text!') (single quotes)
        or
        console.log("This is plain text!") (double quotes)

    Try uncommenting the example below and see that both print exactly the same to the console.
*/

/*
    console.log('This is plain text!')
    console.log("This is plain text!")
*/


/* CODE */

/*
    When you want to log code to see what, for example, the value of your variable is, the procedure is the same as for plain text - except that you do not use quotation marks here.

    Example:
    We have a variable called "firstName":
        
        let firstName = "Julie"
    
    We want to see in the console what the value of the "firstName" variable is.
    
    We do this as follows:
    console.log(firstName)

    Try uncommenting the example below and see that "Julie" is printed to the console.
*/

/*
    let firstName = "Julie"
    console.log(firstName)
*/


/* PLAIN TEXT + CODE */

/*
    It is also possible to log plain text and code simultaneously.
    This is done by having a '+' between your text and variable.
    This is what is called concatenation, which means that a piece of code or a text string can be inserted into another text string.

    Example:
    We would like to log: "Hello, my name is " followed by a name.
    
    We therefore first create a variable to which we give a value:
        let firstName = "Victor"
    
    console.log('Hello, my name is ' + firstName)

    In the example above, we first have the text "Hello, my name is ".
    This is followed by the plus, which binds the subsequent variable "firstName", together with "Hi, my name is ",
    so there will be "Hi, my name is Victor".

    Try uncommenting the example below and see "Hi, I'm Victor" printed in the console.
*/

/*
    let firstName = "Victor"
    console.log('Hello, my name is ' + firstName)
*/



/* ERROR MESSAGES */
/*
    The console is also where you get error messages. There is an error message for almost every situation imaginable.
    You don't have to know them all by any means, nor are you meant to learn them (all) by heart (this is impossible to say the least).

    You therefore take them as you come across them. In the example here, the three error messages you will most often encounter in the first semester when it comes to fetching elements from your HTML into your JavaScript are explained.
*/

/*
    // null //
    "null" is computer language and means "nothing". This error message occurs in connection with fetching an element, when you try to fetch an element via an attribute that the element does not have. This message occurs regardless of whether you use .getElementById(), .querySelector(), or a third-party method to get an element into your JavaScript.

    In short, you're getting "null" because you're trying to fetch an element that doesn't exist into your JavaScript.

    Example:
    We have a <h1></h1> element in the HTML with an id called "header" (see index.html).
    
    We retrieve this element via its id:

        const header = document.getElementById('head')
    
    
    After this, we log the variable "header"

        console.log(header)
    
    Here it is expected that '<h1 id="header"></h1>' is logged to the console, but instead we get "null".
    This happens because we're trying to address the element via its id with a wrong name (the element's id has the value "header", but we're trying to address it with the value "head").
    
    Try uncommenting the example below and see that "null" is printed to the console.
*/

/*
    const header = document.getElementById('head')
    console.log(header)
*/


// SOLUTION //

/*
    There are two ways to resolve this error:

        1. HTML
            First solution is to go into the HTML and change the id to match what you wrote in the brackets in .getElementById(). However, this is usually not done.
        
            
        2. JavaScript
            The second way is to change what is written in .getElementById() to match the id the element has in the HTML. This is the recommended way.
        

    So the correct way is this line of JavaScript:
        
        const header = document.getElementById('header')
*/


/*
   // 
      Uncaught ReferenceError: variableName is not defined (Chrome & Firefox)
      / 
      ReferenceError: Can't find variable: x (Safari)
   //
    
   "Uncaught ReferenceError: variableName is not defined" or "ReferenceError: Can't find variable: x" is the error message that you will encounter when you try to reference a variable that you have not defined.

   Example:
   We log a variable 'x' to the console:
   
       console.log(x)
   
   Since we have not yet declared any variable named 'x', we will get the above error message.

   Try uncommenting the example below and see "Uncaught ReferenceError: x is not defined" or "ReferenceError: Can't find variable: x" printed in the console.
*/

/*
    console.log(x)
*/

// SOLUTION //

/*
    However, the solution to this problem is relatively simple:
    We simply just declare a variable named 'x'.

    Example:
        let x = 3

        Then we log 'x' and see that we get 3 returned:
        console.log(x)
    
    Try uncommenting the example below and see that 3 is printed to the console.
*/

/*
    let x = 3
    console.log(x)
*/


/*
    // 
      Uncaught ReferenceError: can't access lexical declaration 'x' before initialization (Chrome & Firefox)
      / 
      ReferenceError: Cannot access uninitialized variable (Safari)
    //

    This message can be a bit cryptic to understand. What this means is that you are trying to access a variable before you have declared it.

    Example:
    We log a variable 'y' to the console.

        console.log(y)
    
    Next, we create a variable with the name 'y':
        let y = 4
    
    In this case, we're trying to log a variable that JavaScript doesn't yet know about at the time we log it. This results in the error message above.

    Try uncommenting the example below and see that the above error message is printed in the console.
*/


/*
    console.log(y)
    let y = 4
*/

// SOLUTION //
/*
    Fortunately, the solution to this problem is simple:
    We simply change the lines in the above example so that JavaScript knows about the variable before it is logged.

    Try uncommenting the example below and see that 4 error messages are printed in the console.
*/

/*
    let y = 4
    console.log(y)
*/


/* CHALLENGE */

/*
    These challenges test you in, among other things, understanding the error messages described above.
    Each challenge comes with the line of JavaScript where the error is (if the error is in the JavaScript) as well as the console.log() that forces the error to be resolved. When a challenge is solved correctly, the respective text will turn light green when the button just below the text of the task in question is pressed. If the task is not solved correctly, the text will shake and turn red. You can press the button at any time to see if you have solved the task correctly.
*/

/*
    1. null
    Uncomment the code below and see that "null" is returned in the console.
    In this challenge, the error must be found in the HTML in index.html (in the part below the comment where it says: "<!-- ALL HTML RELATED TO CHALLENGE 1 -->").
    
*/

/*
    You should not touch this unless you need to reset the task.
    If this is the case, you just copy and paste it so it is outside
    the comment here:

    const challengeHeaderOne = document.getElementById('challenge_header_one')
    console.log(challengeHeaderOne)
*/


/*
    const challengeHeaderOne = document.getElementById('challenge_header_one')
    console.log(challengeHeaderOne)
*/





/*
    // 2. A little bit of everything //
    In this assignment, there are several things that are wrong, so it is your job to get the code fixed so that it matches the information below. You therefore do not have to write any code yourself, but only correct the existing code so that it will work.

    ATTENTION:
    There may be things in both the HTML (in the part below the comment where it says: "<!-- ALL HTML RELATED TO CHALLENGE 2 -->") and the JavaScript for this challenge, so you need to be alert. 

    Information:
        -> The element must be selected via the id "challenge_header_two"

        -> There are a total of three things that need to be fixed. what they are
           and where each of them has hidden, it is your task to find out.
*/

/*
    console.log(challengeHeaderTwo)
    const challengeHeaderTwo = document.getElementById('#challengE_header_two')
*/

/*
    You should not touch this unless you need to reset the task.
    If this is the case, you just copy and paste it so it says outside
    the comment here:

    console.log(challengeHeaderTwo)
    const challengeHeaderTwo = document.querySelector('.challenge-header-two')
*/
    
    

/*
    // 3. Kreer selv //
    Her skal du selv oprette et element og få det ind i JavaScripten og logget det til konsollen. Opgaven er først løst, når du ikke får en fejlbesked i konsollen men derimod elementet, og teksten bliver grøn, når du trykker på knappen.

    Inde i <header></header>-elementet i HTML'en under kommentaren "<!-- ALT HTML RELATERET TIL UDFORDRING 3 -->" skal du oprette en <h1></h1> med klassen "heading challenge-header-three" (præcis, som det står i citationstegnene her) og id'et "challenge_header_three". Teksten i elementet skal være "Udfordring 3".
    
    Derefter skal du have det ind i JavaScripten via enten dets klasse eller ID, hvorefter du skal logge det til konsollen. Variablen skal hedde "challengeHeaderThree" (stavet præcis sådan).
    
    Teksten bliver lysegrøn, når du har løst opgaven korrekt.

    OBS:
    Det er snyd bare at kopiere og indsætte klasse- og id-navnet herfra og ind i HTML'en.
*/

/*
    // 3. Create yourself //
    Here you have to create an element yourself and get it into the JavaScript and log it to the console. The task is only solved when you do not get an error message in the console but instead the element, and the text turns green when you press the button.

    Inside the <header></header> element in the HTML below the comment "<!-- ALL HTML RELATED TO CHALLENGE 3 -->" create an <h1></h1> with the class "heading challenge-header -three" (exactly as it says in the quotes here) and the id "challenge_header_three". The text in the element should be "Challenge 3".
    
    Then you need to get it into the JavaScript via either its class or ID, then log it to the console. The variable should be called "challengeHeaderThree" (spelled exactly like that).
    
    The text turns light green when you have solved the task correctly.

    ATTENTION:
    It's cheating to just copy and paste the class and id name from here into the HTML.
*/