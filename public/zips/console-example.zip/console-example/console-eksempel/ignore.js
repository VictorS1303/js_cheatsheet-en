const checkButtons = document.querySelectorAll('.btn')
const headings = document.querySelectorAll('.heading')
const headerNumbers = ['one', 'two', 'three']

checkButtons[0].addEventListener('click', () =>
{
    
    if(headings[0].id !== 'challenge_header_one')
    {
        headings[0].classList.add('false')
        checkButtons[0].classList.add('btn-false')

        setTimeout(() =>
        {
            headings[0].classList.remove('false')
            checkButtons[0].classList.remove('btn-false')
        }, 1500)
    }
    else
    {
        headings[0].classList.add('header-correct')
        checkButtons[0].classList.add('btn-correct')
    }
})


checkButtons[1].addEventListener('click', () =>
{
    if(headings[1].id !== 'challenge_header_two')
    {
        headings[1].classList.add('false')
        checkButtons[1].classList.add('btn-false')

        setTimeout(() =>
        {
            headings[1].classList.remove('false')
            checkButtons[1].classList.remove('btn-false')
        }, 1500)
    }
    else
    {
        headings[1].classList.add('header-correct')
        checkButtons[1].classList.add('btn-correct')
    }
})

checkButtons[2].addEventListener('click', () =>
{
    console.log(headings[2].id)
    if(headings[2].id !== 'challenge_header_three')
    {
        headings[2].classList.add('false')
        checkButtons[2].classList.add('btn-false')

        setTimeout(() =>
        {
            headings[2].classList.remove('false')
            checkButtons[2].classList.remove('btn-false')
        }, 1500)
    }
    else
    {
        headings[2].classList.add('header-correct')
        checkButtons[2].classList.add('btn-correct')
    }
})








