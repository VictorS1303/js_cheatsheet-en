<h1>URL PARAMETERS</h1>

<!-- 
    This section is divided into two. One section is about how a URL is constructed, and then the focus is on how parameters can be passed on from page to page.

    ATTENTION:
    This is written in something called Markdown, and since this may be difficult to read as written, it is strongly recommended that you open it in the more readable version by pressing the icon of the two pages with a magnifying glass in lower right corner (the middle icon between the play icon and the icon representing a square divided in two, in the upper right corner).
-->


<h3 style="display: inline-block; border-bottom: 2px solid #fff;">STRUCTURE</h3>
<p>There are two primary parts to a URL: the <em>base URL and the parameters</em>.
<br />
What each of them is and consists of is discussed in depth below.</p>

<h4 style="display: inline-block; border-bottom: 2px solid #fff;">The BASE URL</h4>
<p>The base URL is the part of the URL that never changes, no matter what the page it links to displays. This is the part that typically ends in <em>.html</em>. In our case, the page we need to go to is <em>gender.html</em>, so this is our base URL (see the links in <em>index.html</em>).</p>

![Basis-URL](images/base_url.png)
<br />
<small><em>Base URL</em></small>

<br/>

<h4 style="display: inline-block; border-bottom: 2px solid #fff;">PARAMETERS</h4>
<p>The parameters are the ones that are decisive for what is displayed on the page that is linked to, as it is these that are passed along in the URL. A parameter consists of three things:</p>

<ul>
    <li>
        A name (in our case <span style="color: red;">gender</span>)
        </li>
    <li>
        A <span style="color: #32cd32;">=</span> (equal sign)
    </li>
    <li>
        The parameter's <span style="color: #CDDEFF;">value</span>
    </li>
</ul>


![Parameter-opdeling](images/parameter_parts.png)
<br />
<small><em>Parameter Separation</em></small>

<br/>

<h3 style="display: inline-block; border-bottom: 2px solid #fff;">INDIKATORER</h3>

<h4 style="display: inline-block; border-bottom: 2px solid #fff;">QUESTION MARK</h4>
<p>As seen, there is a question mark between the base URL and the trailing parameter. This indicates that the base URL is over and the first parameter is coming.</p>

![First parameter](images/first_parameter_indicator.png)
<br />
<small><em>Indicating the beginning of the first parameter</em></small>

<h4 style="display: inline-block; border-bottom: 2px solid #fff;">MORE PARAMETERS</h4>
<p>If you want more parameters after the first one, start each of these with an ampersand (&). This looks like the picture, and the syntax for these parameters (after the & sign) is exactly like the first parameter.</p>

![Flere parametre](images/multiple_parameters_indicator.png)


<br />

<h3 style="display: inline-block; border-bottom: 2px solid #fff;">CODE</h3>
<p>
    Here we need to look at how we code-wise get the parameters sent over from one side to the other. This requires some steps which are reviewed one by one below. 
    <br/>
    Both <em>index.html</em> (in "Link Setup") and <em>gender.html</em> (in "Receiving Parameters") are referenced in the walkthrough below, so having them is recommended open when the following is read, so it is easier to follow along.
</p>

<br />

<h3 style="display: inline-block; border-bottom: 2px solid #fff;">1. Link Setup</h3>
<p>
    This is where we define which parameter/parameters the links should pass on.
    <br/>
    In <em>index.html</em> there are two links whose URLs are <b>href="gender.html?gender=boy"</b> and <b>href="gender.html?gender" respectively =girl"</b>.
    <br>
    The links are always on the page from which you want to forward the parameters (which in this case is from <em>index.html</em> to <em>gender.html</em>).
    <br />
    Open <em>index.html</em> and click on one of the links to be redirected to <em>gender.html</em> and then continue below.
</p>

<br/>

<h3 style="display: inline-block; border-bottom: 2px solid #fff;">2. Receiving parameters</h3>
<p>
    The JavaScript that accepts the parameters must be on the page that accepts them. Since it is <em>gender.html</em> that will receive the parameter from <em>index.html</em> here, the JavaScript for this is written in <em>gender.html</em>.
    <br />
    <br />
    Let's see step by step what happens in the <script></script> tag in <em>gender.html</em>. 
</p>

<ol style="background-color: #333; border-radius: 5px; padding-top: 10px; padding-bottom: 10px; padding-right: 20px;">
  <li><b>Tell JavaScript to accept URL parameters</b></li>
  <p>JavaScript needs to know that we are going to work with the URL.
  <br/>
  We tell it this with the line of code below:
   
  <b>const urlParams = new URLSearchParams(window.location.search)</b>

  What happens in the above line?
  <br/>
 
  <em><b>window.location.search</b></em> takes in all the parameters in the URL
  <br/>
  (try uncommenting the line with console.log() on line 19 of <em>gender.html</em>. Remember to uncomment it again). This shows the parameter that the link you clicked on in <em>index.html</em> has.

   <b><em>new URLSearchParams</em></b>, which takes <b><em>window.location.href</em></b> as a parameter, is a built-in JavaScript object that does it is possible to work with URL parameters.

   <b><em>const urlParams</em></b> is just the variable it's all stored in.

   <br />
   <li><b>Get the value of the parameter</b></li>
   JavaScript needs to know about the value of the parameter.
   For this we use the <em><b>.get()</b></em> method, which takes the URL parameter name as a parameter (the URL parameter name in this case is <em>"gender"</ em>) in quotation marks.
   The <em><b>.get()</b></em> method returns the value of the parameter.

   (try uncommenting the line with console.log() on line 23 of <em>gender.html</em>. Remember to uncomment it again). This logs the value of the parameter.
  </p>

  <br />
  <li><b>Print the value of the parameter</b></li>
  To get the value of the parameter printed, we get the span element with the id "gender" into the JavaScript so we have a place to print the value. On the line below, the text in the span element is set to be the value of <em><b>getParams</b></em>, which is the value of the parameter passed in.
  <br />


  In this way, we get the parameter above and print it out in the browser, so that in our case it will read either "<b>Your gender is:</b> boy" or "<b>Your gender is:</b> b> girl:".
</ol>

<br />
<h3 style="display: inline-block; border-bottom: 2px solid #fff;">Challenge</h3>
<br />
<strong>Everything in the challenge must take place in the files in the folder called "challenge".</strong>
<p>
    In <em>challenge_page1.html</em>, create two links that link to <em>challenge_page2.html</em>. Each link must have a parameter called "favorite color", each of which has a value of a color (one of which is your favorite color).
    <br />
    In <em>page2.html</em> the parameter must be picked up so that it will read: "Your favorite color is" followed by the color you have chosen.
    <br />
    <br />
    You must therefore do (in the following order):
</p>

<h5>In <em>challenge.html</em>:</h5>
<ol>
    <li>
        Create two links, each having a parameter called "favorite color", each equal to a color.
        <br/>
        (Hint: Remember what indicates the base URL ends and the first parameter comes).
    </li>
</ol>

<br />
<h5>In <em>page2.html</em>:</h5>
<ol>
    <li>
        Create a variable set equal to the URL parameter
        <br />
        (Hint: new URLSearchParams())
    </li>
    <br />
    <li>
        Get the name of the parameter (which in this case is "favorite color").
        <br />
        (Hint: The name of the variable created in step 1 + .get())
    </li>
    <br />
    <li>
        Grab the span element with its id, in which the choice of color should be.
    </li>
    <br />
    <li>
        Set the text in the span element to equal the variable you created in step 2.
        <br />
        (Hint: variableName.textContent = variableNameFromStepTwo)
    </li>
</ol>