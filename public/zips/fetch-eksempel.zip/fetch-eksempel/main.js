/* FETCH */

/*
    I denne gennemgang gennemgås først, hvordan fetch virker, og hvad det består af. Dernæst gennemgås tre forskellige måder
    at skrive den samme funktionalitet på ("Den lange måde", "den kortere måde" og "async/await-måden").
    I nogle tilfælde er I nødt til at acceptere, at der sker nogle ting, som ikke bliver gået i detaljer med.

    Det er vigtigt at nævne, at fetch returnerer data i det format, der hedder JSON, som står for JavaScript Object Notation.
    Dette vil i korte træk sige, at den data, der returneres, er formateret som objekter, hvorfor man kan tilgå dataen i objekterne
    som i alle andre tilfælde, hvor man arbejder med objekter.

    I eksemplerne nedenfor anvendes der et API, der returnerer et enkelt objekt.
*/


/*
    // Funktion og opbygning //


    1. Hvordan fungerer fetch?
        Forestil dig, at du er ude at lege med en tennisbold med din hund.
        I dette tilfælde er hunden fetch-kaldet, og bolden er dataen, der skal returneres.
        Når du kaster bolden, sender du en forespørgsel på at få noget data returneret (i dette tifælde er bolden dataen).
        Hunden (fetch-kaldet) bliver sendt afsted for at hente bolden (dataen).
        Uanset om hunden (fetch-kaldet) kommer tilbage med eller uden tennisbolden (dataen), har hunden (fetch-kaldet) udført sin opgave korrekt,
        da hundens (fetch-kaldet) eneste opgave er at forsøge at hente det, du forespørger - ikke nødvendigvis at returnere det.
        Så hvis du får en fejlbesked i konsollen (altså, at hunden ikke kommer tilbage med bolden) er dette stadigvæk en succes.
    

    2. Hvad består fetch af?
        Alle måder at lave et et fetch-kald på starter med, at man skriver "fetch('')",
        hvor man inde i citationstegnene i parenteserne angiver den URL, som man ønsker at hente data fra.
        Dernæst kommer to .then()-metoder, som i de forskellige måder at arbejde med dataen på gør noget forskelligt.
*/


/*
    // Den lange version //
    
    I denne udgave fetcher vi dataen, og dernæst anvender vi de to .then()-metoder til henholdsvis at kalde en funktion,
    der formaterer dataen som JSON og til at kalde en funktion, der tager imod den formaterede data og logger det til konsollen.


    Eksempel:

    1. Vi fetcher URL'en

        fetch('https://www.themealdb.com/api/json/v1/1/search.php?s=Arrabiata')


    2. Vi tilføjer en .then()-metode, der kalder en funktion, som formaterer dataen som JSON
        
        fetch('https://www.themealdb.com/api/json/v1/1/search.php?s=Arrabiata').then(headersRecieved)
    

    3. Vi tilføjer endnu en .then()-metode, som kalder den funktion, der logger dataen til konsollen
       
        fetch('https://www.themealdb.com/api/json/v1/1/search.php?s=Arrabiata').then(headersRecieved).then(dataReceived)

    
    4. Vi deklarerer den funktion, der kaldes i den første .then()-metode, som formaterer dataen som JSON

        function headersRecieved(response)
        {
            return response.json()
        }


    5. Vi deklarerer den funktion, der kaldes i den anden .then()-metode, som logger dataen til konsollen

        function dataReceived(data)
        {
            console.log(data)
        }

    Alle disse skridt lagt sammen ser ud som i eksemplet nedenfor.
    Prøv at fjerne kommentarerne fra nedenstående eksempel og se, at "Object { meals: (1) [...] }" bliver logget til konsollen.
*/

/*
    fetch('https://www.themealdb.com/api/json/v1/1/search.php?s=Arrabiata').then(headersRecieved).then(dataReceived)

    function headersRecieved(response)
    {
       // Her returnereres dataen som JSON ved brug af .json()-metoden 
       return response.json()
    }

    function dataReceived(data)
    {
        console.log(data)
    }
*/


/*
    Der er naturligvis hurtigere og bedre måder, der kræver mindre kode, end ovenstående eksempel.
    Dette bliver der kigget på i næste eksempel.
*/

/*
    // Den kortere metode //
    Denne metode minder meget om det, der blev gennegået i eksemplet ovenfor,
    men derfor gennemgås der alligevel skridt for skridt, hvad dcer sker her.


    Eksempel:
    
    1. Vi fetcher URL'en

        fetch('https://www.themealdb.com/api/json/v1/1/search.php?s=Arrabiata')
    
    2. Vi kalder "headersReceived"-funktionen direkte i den første .then()-metode

        fetch('https://www.themealdb.com/api/json/v1/1/search.php?s=Arrabiata').then(function headersReceived(response) {
            return response.json()
        })

    3. Vi tilføjer endnu en .then()-metode, som kalder den funktion, der logger dataen til konsollen
       
        fetch('https://www.themealdb.com/api/json/v1/1/search.php?s=Arrabiata').then(function headersReceived(response) {
            return response.json()
        }).then(dataReceived)
 

    4. Vi deklarerer den funktion, der kaldes i den anden .then()-metode, som logger dataen til konsollen

        function dataReceived(data)
        {
            console.log(data)
        }
    
    
    Alle disse skridt lagt sammen ser ud som i eksemplet nedenfor.
    Prøv at fjerne kommentarerne fra nedenstående eksempel og se, at "Object { meals: (1) [...] }" bliver logget til konsollen.
    Dette er altså en kortere måde at gøre præcis det samme som i "Den lange måde".
*/

/*
      fetch('https://www.themealdb.com/api/json/v1/1/search.php?s=Arrabiata').then(function headersReceived(response) {

        // Her returnereres dataen som JSON ved brug af .json()-metoden 
            return response.json()
        
      }).then(dataReceived)

    function dataReceived(data)
    {
        console.log(data)
    }
*/


/*
    // async/await //
    Der er en endnu kortere måde end de ovenstående, og det er også denne, der anbefales at bruges. Det er her, I er nødt til at acceptere,
    at det ikke er alt, der gås i dybden med, da det bliver for teknisk. Først forklares, hvad async/await er, og dernæst vises,
    hvordan den samme data som i de to ovenstående eksempler kan hentes ind med en enkelt funktion ved brug af async/await
    (dette er dog teknisk et lille skridt op fra de to ovenstående måder).


    // ASYNC //
    Hvad betyder "async"?

        JavaScript er i udgangspunktet synkront. Det vil sige, at den kører hver linje for sig en for en fra top til bund.
        Asynkront JavaScript opfører sig dog på en lidt anden måde.

        En asynkron funktion defineres ved, at man skriver nøgleordet "async",
        før man skriver "function" og det resterende som ved en normal funktionsdeklarering.
        Når JavaScript ser nøgleordet "async", gør den det, at den tager det kode (som regel en funktion), der er defineret med "async",
        og "tager det ud" af JavaScript-filen, hvorefter den fortsætter med at færdiggøre koden i den JavaScript-fil, den er i gang med.
        Først når den er færdig med det, køres den funktion/de funktioner, som er defineret med "async".

        Prøv at se, om du kan gætte, hvilken rækkefølge nedenstående funktioner vil blive kørt.
        Fjern derefter kommentarerne for at se, om du gættede rigtigt (husk at udkommentere det igen).
*/

/*
    async function getMeals()
    {
        const data = await fetch('https://www.themealdb.com/api/json/v1/1/search.php?s=Arrabiata').then(function headersReceived(response) {
            return response.json()
        })

        console.log(data)
    }
    
    function sayHi()
    {
        console.log('Hi!')
    }

    function sayGoodbye()
    {
        console.log('Goodbye!')
    }

   
    sayHi()
    getMeals()
    sayGoodbye()
*/ 



/*
    // AWAIT //

    Hvad betyder "await"?
        
        Nøgleordet "await" kan kun bruges i funktioner deklareret med "async".
        Hvad "await" gør, er, at det fortæller async-funktionen, at den skal vente med at gøre det, der står i funktionen.

        Forestil dig, at du skal hente en ven på stationen.
        Du har ikke fået noget tidspunkt, så derfor kører du med det samme for at være sikker på ikke at komme for sent.
        Det er det, en ikke-asynkron funktion gør - den kører med det samme, den får besked på det.

        Dette vil i kode svare til (console.log() svarer her til, at du kører):

        function driveToStation()
        {
            console.log('Kør til stationen!')
        }

        driveToStation()


        Nu siger din ven så, at han/hun er på stationen om en halv time.
        Du ved, at du skal bruge ti minutter på at komme hen på stationen.
        Du sætter dig ud i din bil med det samme (dette er det synkrone).
        Du venter tyve minutter med at køre. Samtidigt fortsætter din ven med at køre mod stationen (dette svarer til, at JavaScript fortsætter med at køre koden i den fil, den er i gang med).
        Efter de tyve minutter starter kører du, så du kan være på stationen samtidigt med din ven (dette er det asynkrone, da du har ventet i bilen).
    
    
    Det, vi skal awaite i vores async-funktion, er fetch()-kaldet.
    Det hele gennemgås skridt for skridt nedenfor.
*/

/*
   Nu vi ved, hvordan "async" og "await" virker, er det tid til at kigge på,
   hvordan vi kan skrive koden fra skridt 1 og 2 på en kortere måde med "async/await".


   Eksempel:
   
   1. Vi deklararer en asynkron funktion kaldet "getMeal".
       -> Den eneste forskel på dette og en almindelig funktionsdeklarering er, at vi starter med at skrive "async".
    
       async function getMeal()
       {
    
       }


   2. Inde i funktion opretter vi en variabel, som skal være lig med vores asynkrone fetch()-kald
       
       async function getMeal()
       {
            const mealResponse =
       }
   
       
   3. Her foretager vi vores awaitede fetch()-kald
       -> Det er altafgørende, at vi får skrevet "await" efter lighedstegnet og inden "fetch"
    
       async function getMeal()
       {
            const mealResponse = await fetch('https://www.themealdb.com/api/json/v1/1/search.php?s=Arrabiata')
       }
    
  4. Vi opretter en variabel, som er lig med vores data formateret som JSON (denne skal også være "await")
      
       async function getMeal()
       {
            const mealResponse = await fetch('https://www.themealdb.com/api/json/v1/1/search.php?s=Arrabiata')
            const mealResponseAsJSON = await response.json()
            console.log(data)
       }

  5. Vi kalder funktionen, og dermed bliver dataen logget til konsollen som forventet
       getMeal()

    
    Prøv at fjerne kommentarerne fra eksemplet nedenunder og se, at dataen bliver logget til konsollen (husk at udkommentere eksemplet igen)
*/


/*
    async function getMeal()
    {
        const mealResponse = await fetch('https://www.themealdb.com/api/json/v1/1/search.php?s=Arrabiata')
        const mealResponseAsJSON = await mealResponse.json()
        console.log(mealResponseAsJSON)
    }

    getMeal()
*/



/*
    Nedenstående skal I ikke forstå. Det er bare for at vise, hvor kort ovenstående kan gøres.
    Prøv at fjerne kommentarerne fra eksemplet nedenfor og se, at det samme som i alle andre eksempler bliver logget til konsollen (husk at udkommentere eksemplet igen)
*/ 

/*
    async function getData()
    {
        const data = await fetch('https://www.themealdb.com/api/json/v1/1/search.php?s=Arrabiata')
            .then((res) => res.json())
            .then((data) => console.log(data))
    }

    getData()
*/

/*
    Som I kan se, er der mange måder at gøre det samme på - også, når det kommer til fetch.
    Der er her heller ikke nogen rigtig og forkert måde at gøre det på, og det er derfor op til en selv at vælge den måde at gøre det på,
    som man bedst selv forstår og er fortrolig med.
*/


/*** UDFORDRING ***/
/*
    URL:
    https://www.themealdb.com/api/json/v1/1/search.php?s=Arrabiata


    1. Den lange måde/Den kortere måde
       Her skal I bruge den måde, I føler jer mest komfortabel med af enten den korte eller
       den lange måde til at hente dataen fra ovenstående URL ind. I må gerne kigge på den af de to måder, I vælger,
       men I skal skrive det selv og ikke bare kopiere og indsætte eksemplet (dog med undtagelse af URL'en, som I gerne må kopiere og indsætte i fetch()-kaldet.)
       I lærer nemlig ikke noget af bare at kopiere og indsætte.

    
       // Den lange måde //
       I skal derfor (i nedenstående rækkefølge):

       1. Lave et fetch()-kald, der tager ovenstående URL som parametre
          (Hint: Husk citationstegn om URL'en)
    

       2. Tilføj en .then()-metode, der kalder en funktion, der formaterer dataen som JSON
          (Hint: Navnet på funktionen, .then()-metoden kalder, skrives som parameter til .then()-metoden)
    

       3. Tilføj endnu en .then()-metode, der kalder en funktion, der logger dataen til konsollen
          (Hint: Navnet på funktionen, .then()-metoden kalder, skrives som parameter til .then()-metoden)
        

       4. Deklarer funktionen, der skal formatere dataen som JSON
           -> Denne funktion tager et parameter, og det et dette parameter, som .json()-metoden skal kaldes på

          (Hint: Husk "return" som det første inde i funktionen)


       5. Deklarer den funktion, der kaldes i den anden .then()-metode, som logger dataen til konsollen
           -> Denne funktion tager et parameter, og det er dette parameter, som skal logges til konsollen, så dataen udskrives



    2. Async/await
       Her skal I få dataen fra den samme URL ind ved at bruge async/await-metoden.
       Igen her må I ikke bare kopiere eksemplet og indsætte, men I skal der skrive det selv, I bedre forstår og lærer det.


       1. Deklarer en asynkron funktion
          (Hint: "async" før "function", og at funktionen tager et parameter, som er den)
    

       2. Opret en variabel inde i funktionen, som skal være lig med fetch()-kaldet


       3. Skriv fetch()-kaldet lige efter lighedstegnet i variablen, du lavede i forrige skridt
          (Hint: husk "await" før fetch()-kaldet)


       4. Opret endnu en variabel inde i funktionen


       5. Sæt variablen fra forrige skridt til at være lig med dataen formateret som JSON
           (Hint: Navnet på den variabel, du oprettede i skridt 2, efterfulgt af .json(). Husk "await" inden)
    

       6. Log variablen variablen fra skridt 4 til konsollen inde i funktionen


       7. Kald funktionen
*/
