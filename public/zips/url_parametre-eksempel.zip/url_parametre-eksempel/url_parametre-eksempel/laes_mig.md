<h1>URL-PARAMETRE</h1>

<!-- 
    Dette afsnit er delt op i to. Det ene afsnit handler om, hvordan en URL er opbygget, og dernæst fokuseres der på, hvordan parametre kan sendes med videre fra side til side.

    OBS:
    Dette er skrevet i noget, der hedder Markdown, og da dette godt kan være svært at læse, som det står skrevet, anbefales det kraftigt, at det åbnes i den mere læsbare udgave ved at trykke på ikonet af de to sider med et forstørrelsesglas i nederste højre hjørne (det midterste ikon mellem play-ikonet og ikonet, der forestiller en firkant delt i to, oppe i øverste højre hjørne).
-->


<h3 style="display: inline-block; border-bottom: 2px solid #fff;">OPBYGNING</h3>
<p>Der er to primære dele til en URL: <em>basis-URL'en og parametrene</em>.
<br />
Hvad de hver især er og består af, gås der i dybden med nedenfor.</p>


<h4 style="display: inline-block; border-bottom: 2px solid #fff;">BASIS-URL'en</h4>
<p>Basis-URL'en er den del af URL'en, der aldrig ændrer sig, uanset hvad den side, den linker til, skal vise. Det er den del, der typisk ender på <em>.html</em>. I vores tilfælde er den side, vi skal gå til, <em>gender.html</em>, så dette er vores basis-URL (se linksene i <em>index.html</em>).</p>

![Basis-URL](images/base_url.png)
<br />
<small><em>Basis-URL</em></small>

<br/>

<h4 style="display: inline-block; border-bottom: 2px solid #fff;">PARAMETRE</h4>
<p>Parametrerne er dem, der er afgørende for, hvad der bliver vist på den side, der linkes til, da det er disse, der bliver sendt med videre i URL'en. Et parameter består af tre ting:</p>

<ul>
    <li>
        Et navn (i vores tilfælde <span style="color: red;">gender</span>)
        </li>
    <li>
        Et <span style="color: #32cd32;">=</span> (lighedstegn)
    </li>
    <li>
        Parameterets <span style="color: #CDDEFF;">værdi</span>
    </li>
</ul>


![Parameter-opdeling](images/parameter_parts.png)
<br />
<small><em>Parameter-opdeling</em></small>

<br/>

<h3 style="display: inline-block; border-bottom: 2px solid #fff;">INDIKATORER</h3>

<h4 style="display: inline-block; border-bottom: 2px solid #fff;">SPØRGSMÅLSTEGNET</h4>
<p>Som det ses, er der et spørgsmålstegn mellem basis-URL'en og det efterfølgende parameter. Dette indikerer, at basis-URL'en er slut, og det første parameter kommer.</p>

![Første parameter](images/first_parameter_indicator.png)
<br />
<small><em>Indleder til første parameter</em></small>

<h4 style="display: inline-block; border-bottom: 2px solid #fff;">FLERE PARAMETRE</h4>
<p>Ønsker man flere parametre efter det første, indledes hvert af disse med et og-tegn (&). Dette ser ud som på billedet, og syntaksen for disse parametre (efter &-tegnet) er nøjagtigt som det første parameter.</p>

![Flere parametre](images/multiple_parameters_indicator.png)


<br />

<h3 style="display: inline-block; border-bottom: 2px solid #fff;">KODE</h3>
<p>
    Her skal vi til at kigge på, hvordan vi kodemæssigt får parametrene sendt med over fra den ene side til den anden. Dette kræver nogle trin, som gennemgås et for et nedenfor. 
    <br/>
    Der bliver refereret til både <em>index.html</em> (i "Linkopsætning") og <em>gender.html</em> (i "Modtagelse af parametre") i nedenstående gennemgang, så det anbefales at have dem åbne, når nedenstående læses, så det er nemmere at følge med.
</p>

<br />

<h3 style="display: inline-block; border-bottom: 2px solid #fff;">1. Linkopsætning</h3>
<p>
    Det er her, vi definerer, hvilket parameter/hvilke parametre, som linkesne skal sende med videre.
    <br/>
    I <em>index.html</em> er der to links, hvis URL er henholdsvis <b>href="gender.html?gender=dreng"</b> og <b>href="gender.html?gender=pige"</b>.
    <br>
    Linksene er altid på den side, som man ønsker at sende parametrene med videre fra (som i dette tilfælde er fra <em>index.html</em> til <em>gender.html</em>).
    <br />
    Åbn <em>index.html</em>, og tryk på et af linkesene, så du sendes videre til <em>gender.html</em>, og fortsæt dernæst med nedenstående.
</p>

<br/>

<h3 style="display: inline-block; border-bottom: 2px solid #fff;">2. Modtagelse af parametre</h3>
<p>
    Det JavaScript, der tager imod parametrene, skal være på den side, der tager imod dem. Da det er <em>gender.html</em>, der skal tage imod parameteret fra <em>index.html</em> her, er JavaScripten til dette skrevet i <em>gender.html</em>.
    <br />
    <br />
    Lad os se på skridt for skridt, hvad der sker i <script></script>-tagget i <em>gender.html</em>. 
</p>

<ol style="background-color: #333; border-radius: 5px; padding-top: 10px; padding-bottom: 10px; padding-right: 20px;">
  <li><b>Fortæl JavaScript, at den skal tage imod URL-parametre</b></li>
  <p>JavaScript er nødt til at vide, at vi skal til at arbejde med URL'en.
  <br/>
  Dette fortæller vi den med nedenstående linje kode:
   
  <b>const urlParams = new URLSearchParams(window.location.search)</b>

  Hvad sker der i ovenstående linje?
  <br/>
 
  <em><b>window.location.search</b></em> tager fat på alle parametrene i URL'en
  <br/>
  (prøv at fjerne kommentarene fra linjen med console.log() på linje 19 i <em>gender.html</em>. Husk at udkommentere det igen). Her vises det parameter, som det link, du klikkede på i <em>index.html</em>, har.

   <b><em>new URLSearchParams</em></b>, som tager <b><em>window.location.href</em></b> som parameter, er et indbygget objekt i JavaScript, der gør det muligt at arbejde med URL-parametre.

   <b><em>const urlParams</em></b> er bare den variabel, det hele gemmes i.

   <br />
   <li><b>Få fat på værdien af parameteret</b></li>
   JavaScript er nødt til at kende til værdien af parameteret.
   Til dette anvender vi <em><b>.get()</b></em>-metoden, som tager URL-parameterets navn som parameter (URL-parameterets navn er i dette tilfælde <em>"gender"</em>) i citationstegn.
   <em><b>.get()</b></em>-metoden returnerer værdien af parameteret.

   (prøv at fjerne kommentarene fra linjen med console.log() på linje 23 i <em>gender.html</em>. Husk at udkommentere det igen). Dette logger værdien af parameteret.
  </p>

  <br />
  <li><b>Udskriv værdien af parameteret</b></li>
  For at få værdien af parameteret udskrevet, henter vi span-elementet med id'et "gender" ind i JavaScripten, så vi har et sted, vi kan udskrive værdien. På linjen nedenunder sættes teksten i span-elementet til at være værdien af <em><b>getParams</b></em>, som er værdien af det parameter, der er blevet sendt med.
  <br />


  På denne måde får vi altså parameteret med over og udskrevet det i browseren, så der i vores tilfælde kommer til at stå enten "<b>Dit køn er:</b> dreng" eller "<b>Dit køn er:</b> pige:".
</ol>

<br />
<h3 style="display: inline-block; border-bottom: 2px solid #fff;">Udfordring</h3>
<br />
<strong>Alt i udfordringen skal foregå i filerne i mappen kaldet "udfordring".</strong>
<p>
    I <em>udfordring.html</em> skal du oprette to links, der linker til <em>side2.html</em>. Hvert link skal have et parameter kaldet "yndlingsfarve", som hver især har en værdi af en farve (hvor den ene er din yndlingsfarve).
    <br />
    I <em>side2.html</em> skal parameteret samles op, således der kommer til at stå: "Din yndlingsfarve er" efterfulgt af den farve, du har valgt.
    <br />
    <br />
    Du skal derfor gøre (i følgende rækkefølge):
</p>

<h5>I <em>udfordring.html</em>:</h5>
<ol>
    <li>
        Oprette to links, der hver især har et parameter kaldet "yndlingsfarve", der hver især er lig med en farve.
        <br/>
        (Hint: Husk, hvad der indikerer, at basis-URL'en slutter, og det første parameter kommer).
    </li>
</ol>

<br />
<h5>I <em>side2.html</em>:</h5>
<ol>
    <li>
        Oprette en variabel, der er sat til at være lig med URL-parameteret
        <br />
        (Hint: new URLSearchParams())
    </li>
    <br />
    <li>
        Få fat på navnet på parameteret (som i dette tilfælde er "yndlingsfarve").
        <br />
        (Hint: Navnet på variablen oprettet i skridt 1 + .get())
    </li>
    <br />
    <li>
        Få fat på span-elementet med dettes id, hvori valget af farve skal stå.
    </li>
    <br />
    <li>
        Sæt teksten i span-elementet til at være lig med den variabel, du oprettede i skridt 2.
        <br />
        (Hint: variabelNavn.textContent = variabelNavnFraSkridtTo)
    </li>
</ol>