/* TEMPLATE - part I */

/*
    Som nævnt er template en pladsholder - en skabelon - for noget indhold,
    som hentes/genereres dynamisk via JavaScripten. I eksemplet nedenunder beskrives skridt for skridt,
    hvordan man får indholdet fra sin template i HTML'en vist i browseren.
*/

/*
    // .content //
    For at kunne arbejde med indholdet i en template, er vi nødt til først at få fat på dette.
    Det gør man ved først at bringe sin template ind i sin JavaScript som med et hvilket som helst andet element
    ved at sætte det til at være lig med en variabel. Man tilføjer dernæst ".content" for at få fat på indholdet.
    Det hele kommer til at se ud som på linjen nedenunder.
    
    const template = document.querySelector('#template').content
    
    Prøv at fjerne kommentarerne fra nedenstående eksempel og se, at der i konsollen bliver udskrevet
    "DocumentFragment [#text, h1, #text, h1, #text, h1, #text]" (husk at udkommentere eksemplet igen).
    Dette er, fordi vi har skrevet ".content" til sidst, hvilket indikerer, at vi har fået template-elementets indhold med.
*/

/*
    const template = document.querySelector('#template').content
    console.log(template)

*/

/*
    // .cloneNode() //
    Dernæst laver vi en klon af vores template, så vi ikke bare overskriver indholdet i den ene template, som vi har defineret i HTML'en,
    men så vi kan bruge templaten om og om igen med alt muligt forskelligt indhold.
    Dette gøres ved at lave en variabel, som sættes til at være lig med det navn, vi har givet den variabel,
    vi bruger som reference til vores template-element efterfulgt af ".cloneNode()".
    
    Dette ser således ud:
    const templateClone = template.cloneNode()
    
    Problemet med dette er, at denne kun laver en kopi af selve template-elementet, mens alt indholdet bliver ignoreret.
    For at ordne dette skrives ganske enkelt "true" inde i parenteserne.
    
    Derfor kommer det korrekte nu til at se således ud:
    const templateClone = template.cloneNode(true)
    
    Prøv at fjerne kommentarerne fra nedenstående eksempel og se, at der i konsollen nu, som ovenfor, stadigvæk bliver udskrevet "DocumentFragment [#text, h1, #text, h1, #text, h1, #text]".
    Dette er stadigvæk korrekt. 
    
    Prøv før sjov at fjerne "true" fra template.cloneNode() og se, hvad der bliver logget i konsollen (husk at udkommentere eksemplet igen).

    
    OBS:
    Herfra refererer vi kun templateClone-variablen, så vi ikke kommer til at overskrive den oprindelige template.
*/

/*
   const template = document.querySelector('#template').content
   const templateClone = template.cloneNode(true)
   console.log(templateClone)
*/



/*
    // .textContent //
    Her begynder vi at sætte reelt indhold ind i vores template. Dette gøres ved, at der tages fat på templateClone-variablen,
    og .querySelector() bruges til at tage fat på det element, hvis indhold vi gerne vil ændre. Herefter skriver vi .textContent,
    som anvendes til at indsætte tekststrenge i elementer.
    
    Hvis vi vil sætte "name" til at være for eksempel "Victor", vil det se således ud:

    templateClone.querySelector("#name").textContent = 'Victor'

    På samme måde kan vi sætte "age" og "gender":
    templateClone.querySelector("#age").textContent = '24'
    templateClone.querySelector("#gender").textContent = 'Victor'

    Prøv at fjerne kommentarerne fra eksemplet nedenfor og se, at der nu bliver logget "Victor", 24, "Mand" til konsollen (husk at udkommentere eksemplet igen).
*/

/*
    const template = document.querySelector('#template').content

    const templateClone = template.cloneNode(true)

    templateClone.querySelector("#name").textContent = 'Victor'
    templateClone.querySelector("#age").textContent = '24'
    templateClone.querySelector("#gender").textContent = 'Mand'


    console.log 
    (
        templateClone.querySelector("#name").textContent,
        templateClone.querySelector("#age").textContent,
        templateClone.querySelector("#gender").textContent
    )
*/


/*
    // .append()/.appendChild() //
    Indtil nu er intet blevet vist i browseren. Dette er, fordi vi ikke har indsat det i HTML'en.
    For at gøre dette er vi nødt til at bruge .append() eller .appendChild(). Den væsentligste forskel på .append() og .appendChild() er,
    at .append() kan tage flere paremetre, mens .appendChild() kun kan tage et paremeter. Da vi kun skal have et element sat ind i HTML'en,
    anvender vi for lethedens skyld .appendChild().

    For at få templaten vist i browseren skal vi have fat på bodyen, da det er parent-elementet til template-elementet.

    Det ser derfor således ud:
    document.body.appendChild(templateClone)

    Med "document.body" får vi fat på bodyen, og med .appendChild() fortæller vi browseren, at den skal vedhæfte det element,
    som vi giver den med som parameter, hvilket i dette tilfælde er "templateClone".

    Prøv at fjerne kommentarerne fra eksemplet nedenfor og se, at der nu bliver vist følgende i browseren (husk at udkommentere eksemplet igen):

    Navn: Victor
    Alder: 24
    Køn: Mand
*/

/*
    const template = document.querySelector('#template').content

    const templateClone = template.cloneNode(true)

    templateClone.querySelector("#name").textContent = 'Victor'
    templateClone.querySelector("#age").textContent = '24'
    templateClone.querySelector("#gender").textContent = 'Mand'

    document.body.appendChild(templateClone)
*/




/* TEMPLATE - part II -> Objekter */
/*
    Nu vi ved, hvordan vi indsætter data med .textContent, som vi sætter til en eller anden værdi, kan vi nu kigge på,
    hvordan vi indsætter data fra et objekt, da vi allerede ved, hvordan objekter er opbygget.
    Da alt andet undtagen det at indsætte dataen er det samme som ovenfor, bliver dette ikke gennemgået igen her.
*/

/*
    // Vi henter vores template med indhold ind i JavaScripten
    const petTemplate = document.querySelector('#pet_template').content

    // Vi kloner templaten
    const petTemplateClone = petTemplate.cloneNode(true)

    // Vi opretter det objekt, som vi skal bruge til at indsætte data fra
    const pet =
    {
        name: 'Jacob',
        age: 4,
        gender: 'Male',
        breed: 'Hamster',
    }

    Prøv at fjerne kommentarerne fra eksemplet nedenunder og se, at templaten bliver skrevet ud med de værdier, der er angivet i objektet (husk at udkommentere eksemplet igen).  
*/


/*
    
    const pet =
    {
        name: 'Jacob',
        age: 4,
        gender: 'Male',
        breed: 'Hamster',
    }

    // Vi henter vores template med indhold ind i JavaScripten
    const petTemplate = document.querySelector('#pet_template').content

    // Vi kloner templaten
    const petTemplateClone = petTemplate.cloneNode(true)


    
    // Her indsætter vi så dataen fra objektet i templaten (bemærk, at vi her anvender dotnotationen) //

    // Vi tager fat i elementet med id'et "pet_name" og sætter det til at være værdien af "name"
    petTemplateClone.querySelector("#pet_name").textContent = pet.name

    // Vi tager fat i elementet med id'et "pet_age" og sætter det til at være værdien af "age"
    petTemplateClone.querySelector("#pet_age").textContent = pet.age

    // Vi tager fat i elementet med id'et "pet_gender" og sætter det til at være værdien af "gender"
    petTemplateClone.querySelector("#pet_gender").textContent = pet.gender

    // Vi tager fat i elementet med id'et "pet_breed" og sætter det til at være værdien af "breed"
    petTemplateClone.querySelector("#pet_breed").textContent = pet.breed

    // Vi indsætter templaten i browseren
    document.body.appendChild(petTemplateClone)
*/


/*
    // Template/Object Literals //
    Lad os sige, at vi gerne vil have der til at at så "Navn: " foran navnet, "Alder: " foran alderen, "Køn: " før kønnet og "Race: " før racen,
    skal vi anvende noget, der hedder template/object literals. Dette er en anden måde at indsætte data i en streng på.
    Syntaksen kan godt være en smule underlig til at starte med, indtil man har vænnet sig til den.

    Syntaksen er som følger:
        
        `${}`

        -> Først skriver man en backtick ved at trykke på knappen lige til venstre for backspaceknappen
           (bemærk, at denne ikke kommer frem, før du har gennemført næste skridt).

        -> Dernæst laver man et dollartegn
           ("ALT + 4" på Windows og "SHIFT + 4" på MacBook).

        -> Herefter laver man et sæt tuborgparenteser og til allersidst endnu en backtick
           (tryk mellemrum efter "ALT + 4" for at få denne til at komme frem).

    Inde i tuborgparenteserne er der, hvor man tilgår værdierne fra objektet.
    Det ikke dynamiske, som i dette tilfælde er "Navn: ", "Alder: ", "Køn: " og "Race: ",
    skrives mellem den første backtick og dollartegnet.

    Eksempel:
    Vi skal have "Navn: ", "Alder: ", "Køn: " og "Race: " til at stå før deres respektive værdier.
    Jævnfør ovenstående kommer det til at se således ud:

    const pet =
    {
        name: 'Jacob',
        age: 4,
        gender: 'Male',
        breed: 'Hamster',
    }

    // Vi henter vores template med indhold ind i JavaScripten
    const petTemplate = document.querySelector('#pet_template').content

    // Vi kloner templaten
    const petTemplateClone = petTemplate.cloneNode(true)

    // Vi tager fat i elementet med id'et "pet_name" og sætter den til at være værdien af "name" (bemærk placeringen af "Navn: ")
    petTemplateClone.querySelector("#pet_name").textContent = `Navn: ${pet.name}` -> Dette svarer til "Navn: " + pet.name

    // Vi tager fat i elementet med id'et "pet_age" og sætter den til at være værdien af "age" (bemærk placeringen af "Alder: ")
    petTemplateClone.querySelector("#pet_age").textContent = `Alder: ${pet.age}` -> Dette svarer til "Alder: " + pet.age

    // Vi tager fat i elementet med id'et "pet_gender" og sætter den til at være værdien af "gender" (bemærk placeringen af "Køn: ")
    petTemplateClone.querySelector("#pet_gender").textContent = `Køn: ${pet.gender}` -> Dette svarer til "Køn: " + pet.gender

    // Vi tager fat i elementet med id'et "pet_breed" og sætter den til at være værdien af "breed" (bemærk placeringen af "Race: ")
    petTemplateClone.querySelector("#pet_breed").textContent = `Race: ${pet.breed}` -> Dette svarer til "Race: " + pet.breed
    
    // Vi indsætter templaten i browseren
    document.body.appendChild(petTemplateClone)

    Som det ses, er det fuldstændigt samme fremgangsmåde som i forrige eksempel.
    Den eneste ting, der er ændret, er, at vi har anvendt template/object literals til indsætte dynamisk værdi i en tekststreng.

    Prøv at fjerne kommentarerne fra eksemplet nedenfor og se, at der nu står "Navn: ", "Alder: ", "Køn: " og "Race: "
    før deres respektive værdier.
*/


/*
    const pet =
    {
        name: 'Jacob',
        age: 4,
        gender: 'Male',
        breed: 'Hamster',
    }

    // Vi henter vores template med indhold ind i JavaScripten
    const petTemplate = document.querySelector('#pet_template').content

    // Vi kloner templaten
    const petTemplateClone = petTemplate.cloneNode(true)

    // Vi tager fat i elementet med id'et "pet_name" og sætter det til at være værdien af "name"
    petTemplateClone.querySelector("#pet_name").textContent = `Navn: ${pet.name}`

    // Vi tager fat i elementet med id'et "pet_age" og sætter det til at være værdien af "age"
    petTemplateClone.querySelector("#pet_age").textContent = `Alder: ${pet.age}`

    // Vi tager fat i elementet med id'et "pet_gender" og sætter det til at være værdien af "gender"
    petTemplateClone.querySelector("#pet_gender").textContent = `Køn: ${pet.gender}`

    // Vi tager fat i elementet med id'et "pet_breed" og sætter det til at være værdien af "breed"
    petTemplateClone.querySelector("#pet_breed").textContent = `Race: ${pet.breed}`
    
    // Vi indsætter templaten i browseren
    document.body.appendChild(petTemplateClone)
*/


