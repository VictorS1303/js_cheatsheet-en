/*** UDFORDRING ***/

/*
    Udfordringen består i, at der skal indsættes data fra et objekt i en template.
    I skal selv oprette objektet, som I selv må bestemme, hvad skal indholde.
    Før værdien i templaten skal der stå, hvad værdien repræsenterer.
    Hvis det for eksempel er et tal, der repræsenterer en alder, skal der stå fx: "Alder: 24".

    I skal derfor i følgende rækkefølge:

        -> Oprette en template i HTML'en

        -> Oprette et objekt med de værdier, det skal indeholde

        -> Få templaten ind i JavaScripten med indhold (hint: .content)
        
        -> Klone templaten
           (hint: .cloneNode(true))

        -> Sætte værdien af indeholdet af elementerne i templaten til værdierne i objektet
           (hint: template/object literals)
        
        -> Sætte template-klonen ind i browseren (hint: document.body.appendChild())   
*/

/* vvv SKRIV DIN LØSNING HER vvv */

