/* CHALLENGE */

/*
    The challenge consists in inserting data from an object into a template.
    You must create the object yourself, which you must decide what to contain.
    Before the value in the template, what the value represents must be stated.
    If, for example, it is a number that represents an age, it should say, for example: "Age: 24".

    You must therefore in the following order:

        -> Create a template in the HTML

        -> Create an object with the values ​​it must contain

        -> Get the template into the JavaScript with content (hint: .content)
        
        -> Clone the template
           (hint: .cloneNode(true))

        -> Set the value of the contents of the elements in the template to the values ​​in the object
           (hint: template/object literals)
        
        -> Paste the template clone into the browser (hint: document.body.appendChild())   
*/

/* vvv WRITE YOUR SOLUTION HERE vvv */