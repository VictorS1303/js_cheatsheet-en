/* TEMPLATE - part I */

/*
    As mentioned, a template is a placeholder - a template - for some content,
    which is fetched/generated dynamically via the JavaScript. The example below describes step by step,
    how to get the content from your template in the HTML displayed in the browser.
*/

/*
    // .content //
    In order to work with the content in a template, we need to get hold of this first.
    You do this by first bringing your template into your JavaScript as with any other element
    by setting it equal to a variable. You then add ".content" to get hold of the content.
    It will all look like the line below.
    
    const template = document.querySelector('#template').content
    
    Try removing the comments from the example below and see what is printed in the console
    "DocumentFragment [#text, h1, #text, h1, #text, h1, #text]" (remember to comment out the example again).
    This is because we have written ".content" at the end, indicating that we have included the template element's content.
*/

/*
    const template = document.querySelector('#template').content
    console.log(template)

*/


/*
    // .cloneNode() //
    Next, we make a clone of our template, so that we don't just overwrite the content of the one template that we have defined in the HTML,
    but so that we can use the template over and over again with all possible different content.
    This is done by creating a variable which is set to be equal to the name we have given the variable,
    we use as a reference to our template element followed by ".cloneNode()".
    
    This looks like this:
    const templateClone = template.cloneNode()
    
    The problem with this is that it only makes a copy of the template element itself, while all the content is ignored.
    To fix this, simply write "true" inside the brackets.
    
    Therefore, the correct thing will now look like this:
    const templateClone = template.cloneNode(true)
    
    Try removing the comments from the example below and see that the console now, as above, still prints "DocumentFragment [#text, h1, #text, h1, #text, h1, #text]".
    This is still correct. 
    
    For fun, try removing "true" from template.cloneNode() and see what is logged in the console (remember to comment out the example again).

    
    ATTENTION:
    From here we only reference the templateClone variable so we don't end up overwriting the original template.
*/

/*
   const template = document.querySelector('#template').content
   const templateClone = template.cloneNode(true)
   console.log(templateClone)
*/



/*
    // .textContent //
    Here we start putting real content into our template. This is done by addressing the templateClone variable,
    and .querySelector() is used to grab the element whose content we want to change. Then we write .textContent,
    which is used to insert text strings into elements.
    
    If we want to set "name" to be, for example, "Victor", it will look like this:

    templateClone.querySelector("#name").textContent = 'Victor'

    In the same way, we can set "age" and "gender":
    templateClone.querySelector("#age").textContent = '24'
    templateClone.querySelector("#gender").textContent = 'Victor'

    Try uncommenting the example below and see that "Victor", 24, "Male" is now logged to the console (remember to uncomment the example again).
*/

/*
    const template = document.querySelector('#template').content

    const templateClone = template.cloneNode(true)

    templateClone.querySelector("#name").textContent = 'Victor'
    templateClone.querySelector("#age").textContent = '24'
    templateClone.querySelector("#gender").textContent = 'Male'


    console.log 
    (
        templateClone.querySelector("#name").textContent,
        templateClone.querySelector("#age").textContent,
        templateClone.querySelector("#gender").textContent
    )
*/


/*
    // .append()/.appendChild() //
    Until now, nothing has been displayed in the browser. This is because we haven't pasted it into the HTML.
    To do this we need to use .append() or .appendChild(). The main difference between .append() and .appendChild() is,
    that .append() can take several parameters, while .appendChild() can only take one parameter. Since we only need to have one element inserted into the HTML,
    for simplicity we use .appendChild().

    To get the template displayed in the browser, we need to get hold of the body, as it is the parent element of the template element.

    It therefore looks like this:
    document.body.appendChild(templateClone)

    With "document.body" we get the body, and with .appendChild() we tell the browser to attach the element
    which we provide it with as a parameter, which in this case is "templateClone".

    Try removing the comments from the example below and see that the following is now displayed in the browser (remember to uncomment the example again):

    Name: Victor
    Age: 24
    Gender: Male
*/


/*
    const template = document.querySelector('#template').content

    const templateClone = template.cloneNode(true)

    templateClone.querySelector("#name").textContent = 'Victor'
    templateClone.querySelector("#age").textContent = '24'
    templateClone.querySelector("#gender").textContent = 'Mand'

    document.body.appendChild(templateClone)
*/




/* TEMPLATE - part II -> Objects */

/*
    Now that we know how to insert data with .textContent that we set to some value, we can now look at,
    how we insert data from an object, since we already know how objects are structured.
    Since everything else except inserting the data is the same as above, this will not be reviewed again here.
*/

/*
    // We get our template with content into the JavaScript
    const petTemplate = document.querySelector('#pet_template').content

    // We clone the template
    const petTemplateClone = petTemplate.cloneNode(true)

    // We create the object that we need to insert data from
    const pet =
    {
        name: 'Jacob',
        age: 4,
        gender: 'Male',
        breed: 'Hamster',
    }

    Try uncommenting the example below and see that the template is printed with the values ​​specified in the object (remember to uncomment the example again).  
*/


/*
    
    const pet =
    {
        name: 'Jacob',
        age: 4,
        gender: 'Male',
        breed: 'Hamster',
    }

    // We get our template with content into the JavaScript
    const petTemplate = document.querySelector('#pet_template').content

    // We clone the template
    const petTemplateClone = petTemplate.cloneNode(true)


    
    // Here we then insert the data from the object into the template (note that we use the dot notation here) //

    // We grab the element with the id "pet_name" and set it to be the value of "name"
    petTemplateClone.querySelector("#pet_name").textContent = pet.name

    // We grab the element with the id "pet_age" and set it to be the value of "age"
    petTemplateClone.querySelector("#pet_age").textContent = pet.age

    // We grab the element with the id "pet_gender" and set it to be the value of "gender"
    petTemplateClone.querySelector("#pet_gender").textContent = pet.gender

    // We grab the element with the id "pet_breed" and set it to be the value of "breed"
    petTemplateClone.querySelector("#pet_breed").textContent = pet.breed

    // We insert the template into the browser
    document.body.appendChild(petTemplateClone)
*/


/*
    // Template/Object Literals //
    Let's say we want to see "Name: " before the name, "Age: " before the age, "Gender: " before the gender, and "Race: " before the race,
    should we use something called template/object literals. This is another way to insert data into a string.
    The syntax can be a bit strange to start with until you get used to it.

    The syntax is as follows:
        
        `${}`

        -> First you write a backtick by pressing the button just to the left of the backspace button
           (note that this will not appear until you have completed the next step).

        -> Next you make a dollar sign
           ("ALT + 4" on Windows and "SHIFT + 4" on MacBook).

        -> Then you make a set of square brackets and, at the very end, another backtick
           (press space after "ALT + 4" to bring this up).

    Inside the curly braces is where you access the values ​​from the object.
    The non-dynamic, which in this case is "Name: ", "Age: ", "Gender: " and "Race: ",
    is written between the first backtick and the dollar sign.

    Example:
    We need "Name: ", "Age: ", "Gender: " and "Race: " to precede their respective values.
    Comparing the above, it will look like this:

    const pet =
    {
        name: 'Jacob',
        age: 4,
        gender: 'Male',
        breed: 'Hamster',
    }

    // We get our template with content into the JavaScript
    const petTemplate = document.querySelector('#pet_template').content

    // We clone the template
    const petTemplateClone = petTemplate.cloneNode(true)

    // We grab the element with the id "pet_name" and set it to be the value of "name" (note the placement of "Name: ")
    petTemplateClone.querySelector("#pet_name").textContent = `Name: ${pet.name}` -> This is equivalent to "Name: " + pet.name

    // We grab the element with the id "pet_age" and set it to be the value of "age" (note the placement of "Age: ")
    petTemplateClone.querySelector("#pet_age").textContent = `Age: ${pet.age}` -> This is equivalent to "Age: " + pet.age

    // We grab the element with the id "pet_gender" and set it to be the value of "gender" (note the placement of "Gender: ")
    petTemplateClone.querySelector("#pet_gender").textContent = `Gender: ${pet.gender}` -> This is equivalent to "Gender: " + pet.gender

    // We grab the element with the id "pet_breed" and set it to be the value of "breed" (note the placement of "Race: ")
    petTemplateClone.querySelector("#pet_breed").textContent = `Race: ${pet.breed}` -> This is equivalent to "Race: " + pet.breed
    
    // We insert the template into the browser
    document.body.appendChild(petTemplateClone)

    As you can see, it is completely the same procedure as in the previous example.
    The only thing that has changed is that we have used template/object literals to insert dynamic value into a text string.

    Try removing the comments from the example below and see that it now says "Name: ", "Age: ", "Gender: " and "Race: "
    before their respective values.
*/


/*
    const pet =
    {
        name: 'Jacob',
        age: 4,
        gender: 'Male',
        breed: 'Hamster',
    }

    // We get our template with content into the JavaScript
    const petTemplate = document.querySelector('#pet_template').content

    // We clone the template
    const petTemplateClone = petTemplate.cloneNode(true)

    // We grab the element with the id "pet_name" and set it to be the value of "name"
    petTemplateClone.querySelector("#pet_name").textContent = `Name: ${pet.name}`

    // We grab the element with the id "pet_age" and set it to be the value of "age"
    petTemplateClone.querySelector("#pet_age").textContent = `Age: ${pet.age}`

    // We grab the element with the id "pet_gender" and set it to be the value of "gender"
    petTemplateClone.querySelector("#pet_gender").textContent = `Gender: ${pet.gender}`

    // We grab the element with the id "pet_breed" and set it to be the value of "breed"
    petTemplateClone.querySelector("#pet_breed").textContent = `Race: ${pet.breed}`
    
    // We insert the template into the browser
    document.body.appendChild(petTemplateClone)
*/


